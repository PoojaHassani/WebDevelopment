package com.lti.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlets
 */
@WebServlet("/register.do")
public class RegisterServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlets() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("name");
		String code=request.getParameter("empcode");
		String department=request.getParameter("department");
		String day=request.getParameter("day");
		String month=request.getParameter("month");
		String year=request.getParameter("year");
		String textarea=request.getParameter("textarea");
		String[] checkboxNamesList= request.getParameterValues("checkboxNamesList");
		String train=request.getParameter("train");
		String check = "";
		
		for(int i=0; i<checkboxNamesList.length; i++)
			check+=(checkboxNamesList[i]+" ");
		
		response.setContentType("text/html");
		response.getWriter().append("<h1>Employee Details</h1>"
				+ "<table border =''>"
				+ "<tr>"
				+ "<td>Employee name: </td><td>"+name+"</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>Employee Code:</td><td> " +code+"</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>Department:</td><td> " +department+"</td>"
				+ "</tr>"
			
				+ "<tr>"
				+ "<td>Date: </td><td>"+ day+"/"+ month +"/" + year+"</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>Address: </td><td>" + textarea+"</td>"
				+ "</tr>"
				+"<tr>"
				+"<td>Training program attended </td><td>" + check +"</td>"
				+"</tr>"
				+"<tr>"
				+"<td>Training program needed to attend </td><td>" + train +"</td>"
				+"</tr>"
				+ "</table>"
				);
		
	}

}
